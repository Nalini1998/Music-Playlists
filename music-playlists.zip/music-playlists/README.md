# Music Playlists

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/ExGaMpg/0d7c66a93a8cb2ec07918bebfdf502e7](https://codepen.io/Nalini1998/pen/ExGaMpg/0d7c66a93a8cb2ec07918bebfdf502e7).

Mini Music Player built with VueJs. design by Voicu Apostol on dribbble. 

design: https://dribbble.com/shots/3533847-Mini-Music-Player